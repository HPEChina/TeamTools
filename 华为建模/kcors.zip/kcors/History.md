
2.2.0 / 2016-09-26
==================

  * feat: add PATCH to default methods

2.1.1 / 2016-05-14
==================

  * fix: keepHeadersOnError won't affect OPTIONS request (#17)

2.1.0 / 2016-04-29
==================

  * feat: Keep headers after an error (#13)
  * chore: use eslint instead of jshint (#10)
  * test: use codecov instead of coveralls

2.0.0 / 2016-02-20
==================

  * chore: make node engines >= 4.3.1
  * doc: update example
  * test: only test on node 4+
  * refactor: src,test: update to (ctx, next) -> Promise middleware contract
  * chore: base on koa@2

1.0.1 / 2015-02-11
==================

 * fix: make more spec-compliant

1.0.0 / 2015-02-09
==================

 * first release
